//
// Created by arjun on 9/27/24.
//

#ifndef PRJ_SERVERHEADER_H
#define PRJ_SERVERHEADER_H

#include "frnetlib/TcpListener.h"
#include "frnetlib/WebSocket.h"
#include "frnetlib/TcpSocket.h"
#include "frnetlib/Packet.h"


class Request : public fr::Packetable
{
public:
    enum class Opcode : uint8_t
    {
        SocketInit = 1,
        Toogle = 2,
        SeekBar = 3,
        ESP = 4
    };
    inline void set_opcode(Opcode opcode_)
    {
        opcode = opcode_;
    }
    inline void set_id(int id_){
        id = id_;
    }
    inline void set_value(int value_){
        value = value_;
    }
    inline void set_boolean(int value_){
        boolean = value_;
    }
    inline Opcode get_opcode()
    {
        return opcode;
    }
    inline int get_id()
    {
        return id;
    }
    inline int get_value()
    {
        return value;
    }
    inline int get_boolean()
    {
        return boolean;
    }

    virtual void pack(fr::Packet &o) const override
    {
        o << opcode << id << value << boolean;
    }
    virtual void unpack(fr::Packet &o) override
    {
        o >> opcode >> id >> value >> boolean;
    }

private:
    Opcode opcode;
    int id, value, boolean = 0;
};

class SocketInit : public fr::Packetable
{
public:
    enum class Opcode : uint8_t
    {
        SocketInit = 1,
    };
    inline void set_opcode(Opcode opcode_)
    {
        opcode = opcode_;
    }
    inline void set_init(bool value)
    {
        init = value;
    }
    inline bool get_init()
    {
        return init;
    }
    inline Opcode get_opcode()
    {
        return opcode;
    }
    virtual void pack(fr::Packet &o) const override
    {
        o << opcode << init;
    }
    virtual void unpack(fr::Packet &o) override
    {
        o >> opcode >> init;
    }
    Opcode opcode;
    bool init;
};


class Response : public fr::Packetable
{
public:
    enum class Opcode : uint8_t
    {
        Start = 1,
        Toogle = 2,
        SeekBar = 3,
        ESP = 4,
        Stop = 5,
    };
    inline void set_opcode(Opcode opcode_)
    {
        opcode = opcode_;
    }
    inline Opcode get_opcode()
    {
        return opcode;
    }
    virtual void pack(fr::Packet &o) const override
    {
        o << opcode;
    }
    virtual void unpack(fr::Packet &o) override
    {
        o >> opcode;
    }
private:
    Opcode opcode;
};

#endif //PRJ_SERVERHEADER_H
