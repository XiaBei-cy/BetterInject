//
// Created by arjun on 9/28/24.
//
#include "jni.h"
#include <xdl.h>
static int loaded = 0;

extern "C" jint JNIEXPORT JNI_OnLoad(JavaVM* vm, void *key)
{

    void *dl = xdl_open("/data/local/tmp/libServer.so", RTLD_NOW);

//    // key 1337 is passed by injector
//    if (key != (void*)1337)
//    return JNI_VERSION_1_6;
//
//    if (loaded) {
//    return 0;
//    }
//    loaded = 1;
//    if (vm == NULL) {
//    return 0;
//    }
//    JavaVM* jvm = vm;
//    if (jvm == NULL) {
//    return 0;
//    }
//    JNIEnv* env;
//    jint res;
//    res = jvm->AttachCurrentThread(&env, NULL);
//    if (res != JNI_OK) {
//    } else {
//    jclass System = env->FindClass(("java/lang/System"));
//    jmethodID load = env->GetStaticMethodID(System, ("load"), ("(Ljava/lang/String;)V"));
//    env->CallStaticVoidMethod(System, load, env->NewStringUTF(("/data/local/tmp/libServer.so")));
//    }
    return JNI_VERSION_1_6;
}